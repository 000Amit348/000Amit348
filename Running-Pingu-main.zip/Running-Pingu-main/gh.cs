﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gh : MonoBehaviour
{
    Start is called before the first frame update
    void Start()
    {
        Debug.Log(Input.GetKeyDown(KeyCode.A));
        
    }

    Update is called once per frame
    void Update()
    {
        
    }
}
